<?php
// First, we set the page title for this specific page
// This variable will be used in header.php
$pageTitle = "Home";
?>

<?php
// Include the header file
// This adds all the common head and header content
require_once 'includes/header.php';
?>

<section class="content-section section-blue">
    <h2 class="section-heading heading-blue">Welcome to Our Web Development Course</h2>

    <article class="content-article article-blue">
        <h3 class="article-heading">
            <span class="article-icon-blue">▸</span> About This Course
        </h3>
        <p class="text-body mb-3">This course provides comprehensive training in modern web development technologies, starting with HTML5 fundamentals.</p>
        <p class="text-body">You'll learn to create semantic, accessible web pages that follow current web standards.</p>
    </article>

    <article class="content-article article-red">
        <h3 class="article-heading">
            <span class="article-icon-red">▸</span> Course Features
        </h3>
        <ul class="bullet-list">
            <li>HTML5 Semantic Elements</li>
            <li>Forms and Input Validation</li>
            <li>Accessibility Best Practices</li>
            <li>Responsive Design Principles</li>
        </ul>
    </article>

    <article class="content-article article-orange">
        <h3 class="article-heading">
            <span class="article-icon-orange">▸</span> What You'll Learn
        </h3>
        <ol class="numbered-list">
            <li>HTML5 structure and semantics</li>
            <li>Creating accessible web forms</li>
            <li>Building multi-page websites</li>
            <li>Web standards and best practices</li>
        </ol>
    </article>
</section>

<?php
// Include the footer file
// This adds all the common footer content and closes HTML tags
require_once 'includes/footer.php';
?>