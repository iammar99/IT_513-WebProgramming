<?php
// Set the page title for this specific page
$pageTitle = "Contact Us";

// Start session for error messages
session_start();

// Get any stored form data or errors
$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : [];
$form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : [];
$success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : '';

// Clear session messages
unset($_SESSION['errors']);
unset($_SESSION['form_data']);
unset($_SESSION['success_message']);
?>

<?php
// Include the header file
require_once 'includes/header.php';
?>

<section class="content-section section-blue">
    <h2 class="section-heading heading-blue">Contact Us</h2>

    <!-- Display Success Message -->
    <?php if (!empty($success_message)): ?>
        <div class="alert-success">
            <?php echo htmlspecialchars($success_message); ?>
        </div>
    <?php endif; ?>

    <!-- Display Error Messages -->
    <?php if (!empty($errors)): ?>
        <div class="alert-error">
            <h4 class="alert-heading">Please fix the following errors:</h4>
            <ul class="alert-list">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <article class="content-article article-blue">
        <h3 class="article-heading">
            <span class="article-icon-blue">▸</span> Get in Touch
        </h3>
        <p class="text-body mb-6">We'd love to hear from you. Please use the form below to send us a message.</p>

        <form action="processing_pages/process-contact.php" method="POST" class="max-w-2xl mx-auto space-y-6">
            <div class="form-group">
                <label for="contact-name" class="form-label">Your Name:</label>
                <input type="text" id="contact-name" name="contact-name" required
                    value="<?php echo isset($form_data['contact-name']) ? htmlspecialchars($form_data['contact-name']) : ''; ?>"
                    class="form-input">
            </div>

            <div class="form-group">
                <label for="contact-email" class="form-label">Your Email:</label>
                <input type="email" id="contact-email" name="contact-email" required
                    value="<?php echo isset($form_data['contact-email']) ? htmlspecialchars($form_data['contact-email']) : ''; ?>"
                    class="form-input">
            </div>

            <div class="form-group">
                <label for="contact-subject" class="form-label">Subject:</label>
                <select id="contact-subject" name="contact-subject" required class="form-select">
                    <option value="">Select a subject</option>
                    <option value="general" <?php echo (isset($form_data['contact-subject']) && $form_data['contact-subject'] == 'general') ? 'selected' : ''; ?>>General Inquiry</option>
                    <option value="course" <?php echo (isset($form_data['contact-subject']) && $form_data['contact-subject'] == 'course') ? 'selected' : ''; ?>>Course Information</option>
                    <option value="technical" <?php echo (isset($form_data['contact-subject']) && $form_data['contact-subject'] == 'technical') ? 'selected' : ''; ?>>Technical Support</option>
                    <option value="billing" <?php echo (isset($form_data['contact-subject']) && $form_data['contact-subject'] == 'billing') ? 'selected' : ''; ?>>Billing Question</option>
                    <option value="other" <?php echo (isset($form_data['contact-subject']) && $form_data['contact-subject'] == 'other') ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>

            <div class="form-group">
                <label for="contact-message" class="form-label">Message:</label>
                <textarea id="contact-message" name="contact-message" rows="6" required
                    class="form-textarea min-h-32"><?php echo isset($form_data['contact-message']) ? htmlspecialchars($form_data['contact-message']) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label">Preferred Contact Method:</label>
                <div class="flex items-center space-x-6">
                    <label class="radio-group">
                        <input type="radio" id="contact-email-method" name="contact-method" value="email"
                            <?php echo (!isset($form_data['contact-method']) || $form_data['contact-method'] == 'email') ? 'checked' : ''; ?>
                            class="radio-input">
                        <span class="text-body">Email</span>
                    </label>
                    <label class="radio-group">
                        <input type="radio" id="contact-phone-method" name="contact-method" value="phone"
                            <?php echo (isset($form_data['contact-method']) && $form_data['contact-method'] == 'phone') ? 'checked' : ''; ?>
                            class="radio-input">
                        <span class="text-body">Phone</span>
                    </label>
                </div>
            </div>

            <div class="flex space-x-4 pt-4">
                <input type="submit" value="Send Message" class="btn-submit">
                <input type="reset" value="Clear Form" class="btn-reset">
            </div>
        </form>
    </article>

    <article class="content-article article-purple">
        <h3 class="article-heading">
            <span class="article-icon-purple">▸</span> Our Location
        </h3>
        <address class="address-block">
            WebDev Training Center<br>
            123 Learning Street<br>
            Tech City, TC 10101<br>
            Email: <a href="mailto:info@webdevcourse.com" class="address-link">info@webdevcourse.com</a><br>
            Phone: <a href="tel:+15551234567" class="address-link">(555) 123-4567</a>
        </address>
    </article>
</section>

<?php
// Include the footer file
require_once 'includes/footer.php';
?>