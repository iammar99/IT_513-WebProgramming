<?php
// This is the header include file
// It contains the DOCTYPE, HTML head, and header section
// We can include this at the top of every page
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/output.css">
    <title>WebDev Course -
        <?php
        // This PHP block sets the page title dynamically
        // We'll set $pageTitle in each file before including header.php
        if (isset($pageTitle)) {
            echo $pageTitle;
        } else {
            echo "Home"; // Default title if none is set
        }
        ?>
    </title>
</head>

<body class="page-container">
    <header class="site-header">
        <h1 class="site-title">WebDev Course</h1>
        <?php
        // Include the navigation menu here
        // The require_once ensures the file is included and shows error if missing
        require_once __DIR__ . '/navigation.php';
        ?>
    </header>

    <main class="main-content">