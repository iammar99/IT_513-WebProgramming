<?php
// This file contains the navigation menu that is used in both header and footer
// It can be included in multiple places to avoid code repetition
?>
<nav>
    <ul class="nav-container">
        <li><a href="index.php" class="nav-link">Home</a></li>
        <li><a href="registration.php" class="nav-link">Registration</a></li>
        <li><a href="products.php" class="nav-link">Products</a></li>
        <li><a href="contact.php" class="nav-link">Contact Us</a></li>
    </ul>
</nav>