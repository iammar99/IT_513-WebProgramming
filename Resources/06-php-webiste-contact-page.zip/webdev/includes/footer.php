<?php
// This is the footer include file
// It contains the footer section that is common to all pages
?>
</main>

<footer class="site-footer">
    <p class="footer-text">&copy; 2023 Web Development Course. All rights reserved.</p>
    <?php
    // Include the same navigation menu in the footer
    require_once __DIR__ . '/navigation.php';
    ?>
    <p class="footer-note">This website demonstrates HTML5 semantic structure with Tailwind CSS styling.</p>
</footer>
</body>

</html>