<?php
// Set the page title for this specific page
$pageTitle = "Registration";
?>

<?php
// Include the header file with all common head and header content
require_once 'includes/header.php';
?>

<section class="content-section section-blue">
    <h2 class="section-heading heading-blue">User Registration</h2>

    <form action="registration-success.php" method="get" class="form-container">
        <fieldset class="form-fieldset fieldset-blue">
            <legend class="fieldset-legend legend-blue">Personal Information</legend>

            <div class="form-grid">
                <div class="form-group">
                    <label for="first-name" class="form-label">First Name:</label>
                    <input type="text" id="first-name" name="first-name" required class="form-input">
                </div>

                <div class="form-group">
                    <label for="last-name" class="form-label">Last Name:</label>
                    <input type="text" id="last-name" name="last-name" required class="form-input">
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" id="email" name="email" required class="form-input">
                </div>

                <div class="form-group">
                    <label for="phone" class="form-label">Phone:</label>
                    <input type="tel" id="phone" name="phone" class="form-input">
                </div>
            </div>
        </fieldset>

        <fieldset class="form-fieldset fieldset-red">
            <legend class="fieldset-legend legend-red">Account Information</legend>

            <div class="form-grid">
                <div class="form-group">
                    <label for="username" class="form-label">Username:</label>
                    <input type="text" id="username" name="username" required class="form-input">
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" id="password" name="password" required minlength="8" class="form-input">
                </div>

                <div class="form-group md:col-span-2">
                    <label for="confirm-password" class="form-label">Confirm Password:</label>
                    <input type="password" id="confirm-password" name="confirm-password" required class="form-input">
                </div>
            </div>
        </fieldset>

        <fieldset class="form-fieldset fieldset-orange">
            <legend class="fieldset-legend legend-orange">Additional Information</legend>

            <div class="form-grid">
                <div class="form-group">
                    <label for="birthdate" class="form-label">Birth Date:</label>
                    <input type="date" id="birthdate" name="birthdate" class="form-input">
                </div>

                <div class="form-group">
                    <label for="course-level" class="form-label">Course Level:</label>
                    <select id="course-level" name="course-level" class="form-select">
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>

                <div class="form-group md:col-span-2">
                    <label class="form-label">Interests:</label>
                    <div class="flex flex-col md:flex-row gap-4">
                        <label class="checkbox-group">
                            <input type="checkbox" id="frontend" name="interests" value="frontend" class="checkbox-input">
                            <span class="text-body">Frontend Development</span>
                        </label>

                        <label class="checkbox-group">
                            <input type="checkbox" id="backend" name="interests" value="backend" class="checkbox-input">
                            <span class="text-body">Backend Development</span>
                        </label>

                        <label class="checkbox-group">
                            <input type="checkbox" id="fullstack" name="interests" value="fullstack" class="checkbox-input">
                            <span class="text-body">Full Stack Development</span>
                        </label>
                    </div>
                </div>

                <div class="form-group md:col-span-2">
                    <label for="comments" class="form-label">Comments:</label>
                    <textarea id="comments" name="comments" rows="4" class="form-textarea"></textarea>
                </div>
            </div>
        </fieldset>

        <div class="btn-container">
            <input type="submit" value="Register" class="btn-submit">
            <input type="reset" value="Clear Form" class="btn-reset">
        </div>
    </form>
</section>

<?php
// Include the footer file with all common footer content
require_once 'includes/footer.php';
?>