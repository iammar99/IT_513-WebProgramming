<?php
$pageTitle = "Registration Successful";
require_once 'includes/header.php';
?>

<section class="content-section section-green">
    <h2 class="section-heading heading-green">Registration Successful!</h2>

    <article class="content-article article-green text-center-content">
        <div class="mb-6">
            <svg class="success-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <h3 class="success-heading">Welcome to WebDev Course!</h3>
            <p class="success-text">Thank you for registering with us.</p>
            <p class="text-body mb-4">Your account has been created successfully.</p>
            <p class="text-muted text-sm">We'll send a confirmation email shortly with further instructions.</p>
        </div>

        <div class="btn-container">
            <a href="/index.php" class="btn-primary">
                Go to Homepage
            </a>
            <a href="/products.php" class="btn-secondary">
                Browse Courses
            </a>
        </div>
    </article>
</section>

<?php require_once 'includes/footer.php'; ?>