<?php
$pageTitle = "Message Sent";
require_once __DIR__ . '/../../includes/header.php';
?>

<section class="content-section section-green">
    <h2 class="section-heading heading-green">Message Sent Successfully!</h2>

    <article class="content-article article-green text-center-content">
        <div class="mb-6">
            <svg class="success-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <h3 class="success-heading">Thank You for Contacting Us!</h3>
            <p class="success-text">Your message has been received successfully.</p>
            <p class="text-body mb-6">We'll get back to you within 24 hours.</p>
        </div>

        <div class="btn-container">
            <a href="/index.php" class="btn-primary">
                Return to Homepage
            </a>
            <a href="/contact.php" class="btn-tertiary">
                Send Another Message
            </a>
        </div>
    </article>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>