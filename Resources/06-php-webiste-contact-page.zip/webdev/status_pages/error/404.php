<?php
// Set the page title for the 404 error page
$pageTitle = "Page Not Found";
?>

<?php
// Include the header file
require_once 'includes/header.php';
?>

<section class="content-section section-orange">
    <h2 class="section-heading heading-orange">404 - Page Not Found</h2>

    <article class="content-article article-orange">
        <h3 class="article-heading">
            <span class="article-icon-orange">▸</span> Oops! The page you're looking for doesn't exist.
        </h3>
        <p class="text-body mb-6">It seems like the page you tried to access has been moved, deleted, or never existed.</p>

        <div class="content-article article-orange mb-6">
            <h4 class="article-heading">
                <span class="article-icon-orange">▸</span> What you can do:
            </h4>
            <ul class="bullet-list">
                <li>Check the URL for typos</li>
                <li>Go back to the <a href="index.php" class="address-link">homepage</a></li>
                <li>Use the navigation menu above to find what you need</li>
                <li><a href="contact.php" class="address-link">Contact us</a> if you need help</li>
            </ul>
        </div>

        <p class="text-muted mb-6"><strong>Technical details:</strong> Error 404 - Resource not found</p>

        <div class="btn-container">
            <a href="index.php" class="btn-primary">
                Return to Homepage
            </a>
            <a href="contact.php" class="btn-secondary">
                Contact Support
            </a>
        </div>
    </article>
</section>

<?php
// Include the footer file
require_once 'includes/footer.php';
?>