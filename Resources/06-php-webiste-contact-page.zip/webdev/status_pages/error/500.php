<?php
// Set the page title for the 500 error page
$pageTitle = "Server Error";
?>

<?php
// Include the header file
require_once 'includes/header.php';
?>

<section class="content-section section-purple">
    <h2 class="section-heading heading-purple">500 - Server Error</h2>

    <article class="content-article article-purple">
        <h3 class="article-heading">
            <span class="article-icon-purple">▸</span> We're experiencing some technical difficulties.
        </h3>
        <p class="text-body mb-6">Our server encountered an internal error and couldn't complete your request.</p>

        <div class="content-article article-purple mb-6">
            <h4 class="article-heading">
                <span class="article-icon-purple">▸</span> Please try the following:
            </h4>
            <ul class="bullet-list">
                <li>Refresh the page in a few minutes</li>
                <li>Go back to the <a href="index.php" class="address-link">homepage</a></li>
                <li>Clear your browser cache and try again</li>
                <li>If the problem persists, <a href="contact.php" class="address-link">contact our support team</a></li>
            </ul>
        </div>

        <p class="text-body mb-4">We apologize for the inconvenience and are working to fix the issue.</p>
        <p class="text-muted mb-6"><strong>Technical details:</strong> Error 500 - Internal Server Error</p>

        <div class="btn-container">
            <a href="index.php" class="btn-primary">
                Return to Homepage
            </a>
            <a href="contact.php" class="btn-reset">
                Report Issue
            </a>
        </div>
    </article>
</section>

<?php
// Include the footer file
require_once 'includes/footer.php';
?>