<?php
// Set the page title for the maintenance page
$pageTitle = "Maintenance Mode";
?>

<?php
// Include the header file
require_once 'includes/header.php';
?>

<section class="content-section section-red">
    <h2 class="section-heading heading-red">Maintenance Mode</h2>

    <article class="content-article article-red">
        <h3 class="article-heading">
            <span class="article-icon-red">▸</span> Website Under Maintenance
        </h3>
        <p class="text-body mb-6">We're currently performing scheduled maintenance to improve your experience.</p>

        <div class="content-article article-red mb-6">
            <h4 class="article-heading">
                <span class="article-icon-red">▸</span> What's happening:
            </h4>
            <ul class="bullet-list">
                <li>Server updates and optimizations</li>
                <li>New feature implementations</li>
                <li>Security enhancements</li>
                <li>Performance improvements</li>
            </ul>
        </div>

        <div class="content-article article-orange mb-6">
            <h4 class="article-heading">
                <span class="article-icon-orange">▸</span> Estimated downtime:
            </h4>
            <p class="text-body">We expect to be back online in approximately 2 hours.</p>
            <p class="text-muted">Last updated: <?php echo date('F j, Y \a\t g:i A'); ?></p>
        </div>

        <p class="text-body mb-4">Thank you for your patience. We'll be back soon with an improved experience.</p>
        <p class="text-muted mb-6"><strong>Status:</strong> Scheduled Maintenance</p>

        <div class="btn-container">
            <a href="javascript:location.reload()" class="btn-primary">
                Try Again
            </a>
            <a href="contact.php" class="btn-secondary">
                Contact Support
            </a>
        </div>
    </article>
</section>

<?php
// Include the footer file
require_once 'includes/footer.php';
?>