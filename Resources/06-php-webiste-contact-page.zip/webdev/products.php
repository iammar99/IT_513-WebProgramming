<?php
// Set the page title for this specific page
$pageTitle = "Products";
?>

<?php
// Include the header file
require_once 'includes/header.php';
?>

<section class="content-section section-blue">
    <h2 class="section-heading heading-blue">Our Products</h2>

    <article class="content-article article-blue">
        <h3 class="article-heading">
            <span class="article-icon-blue">▸</span> Web Development Courses
        </h3>
        <div class="table-container">
            <table class="data-table">
                <caption class="table-caption">Course Offerings and Pricing</caption>
                <thead class="table-header">
                    <tr>
                        <th class="table-header-cell">Course Name</th>
                        <th class="table-header-cell">Duration</th>
                        <th class="table-header-cell">Level</th>
                        <th class="table-header-cell">Price</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <tr class="table-row">
                        <td class="table-cell">HTML5 Fundamentals</td>
                        <td class="table-cell">4 weeks</td>
                        <td class="table-cell">Beginner</td>
                        <td class="table-cell-bold">$99</td>
                    </tr>
                    <tr class="table-row-striped">
                        <td class="table-cell">CSS3 Styling</td>
                        <td class="table-cell">6 weeks</td>
                        <td class="table-cell">Intermediate</td>
                        <td class="table-cell-bold">$149</td>
                    </tr>
                    <tr class="table-row">
                        <td class="table-cell">JavaScript Programming</td>
                        <td class="table-cell">8 weeks</td>
                        <td class="table-cell">Intermediate</td>
                        <td class="table-cell-bold">$199</td>
                    </tr>
                    <tr class="table-row-striped">
                        <td class="table-cell">Full Stack Development</td>
                        <td class="table-cell">12 weeks</td>
                        <td class="table-cell">Advanced</td>
                        <td class="table-cell-bold">$399</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>

    <article class="content-article article-red">
        <h3 class="article-heading">
            <span class="article-icon-red">▸</span> Learning Resources
        </h3>
        <ul class="bullet-list">
            <li>Interactive Coding Exercises</li>
            <li>Video Tutorials</li>
            <li>Project Templates</li>
            <li>Community Support</li>
            <li>Code Review Sessions</li>
            <li>Weekly Q&A Webinars</li>
        </ul>
    </article>

    <article class="content-article article-orange">
        <h3 class="article-heading">
            <span class="article-icon-orange">▸</span> Certification Programs
        </h3>
        <p class="text-body mb-4">Complete our courses to earn industry-recognized certifications that validate your web development skills.</p>
        <details class="details-container">
            <summary class="details-summary">
                View Certification Requirements
            </summary>
            <div class="details-content">
                <ul class="bullet-list">
                    <li>Complete all course modules</li>
                    <li>Pass final assessment with 80% or higher</li>
                    <li>Submit a capstone project</li>
                    <li>Participate in community discussions</li>
                </ul>
            </div>
        </details>
    </article>

    <article class="content-article article-purple">
        <h3 class="article-heading">
            <span class="article-icon-purple">▸</span> Course Bundles
        </h3>
        <div class="table-container">
            <table class="data-table">
                <caption class="table-caption">Save with Our Course Bundles</caption>
                <thead class="table-header">
                    <tr>
                        <th class="table-header-cell">Bundle Name</th>
                        <th class="table-header-cell">Courses Included</th>
                        <th class="table-header-cell">Individual Price</th>
                        <th class="table-header-cell">Bundle Price</th>
                        <th class="table-header-cell">Savings</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <tr class="table-row">
                        <td class="table-cell-bold">Frontend Foundation</td>
                        <td class="table-cell">HTML5 + CSS3 + JavaScript</td>
                        <td class="table-cell">$447</td>
                        <td class="table-cell-bold">$349</td>
                        <td class="table-cell-success">$98</td>
                    </tr>
                    <tr class="table-row-striped">
                        <td class="table-cell-bold">Complete Web Developer</td>
                        <td class="table-cell">All 4 Courses</td>
                        <td class="table-cell">$846</td>
                        <td class="table-cell-bold">$599</td>
                        <td class="table-cell-success">$247</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>
</section>

<?php
// Include the footer file
require_once 'includes/footer.php';
?>