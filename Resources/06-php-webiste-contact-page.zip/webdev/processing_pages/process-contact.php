<?php
// process-contact.php
// This file processes the contact form and saves to database

// Start session for error messages
session_start();

// Fix relative path for database include - use your existing database file
require_once __DIR__ . '/../includes/db/database.php';

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form data and sanitize
    $name = trim($_POST['contact-name']);
    $email = trim($_POST['contact-email']);
    $subject = trim($_POST['contact-subject']);
    $message = trim($_POST['contact-message']);
    $contact_method = isset($_POST['contact-method']) ? $_POST['contact-method'] : 'email';

    // Initialize error array
    $errors = [];

    // Validate form data
    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if (empty($subject)) {
        $errors[] = "Subject is required";
    }

    if (empty($message)) {
        $errors[] = "Message is required";
    }

    // If no errors, save to database
    if (empty($errors)) {
        try {
            // Get database connection using your existing Database class
            $database = new Database();
            $db = $database->getConnection();

            // Check if connection is successful
            if ($db) {
                // Prepare SQL query
                $query = "INSERT INTO contacts 
                         (name, email, subject, message, contact_method) 
                          VALUES 
                         (:name, :email, :subject, :message, :contact_method)";

                $stmt = $db->prepare($query);

                // Bind parameters
                $stmt->bindParam(":name", $name);
                $stmt->bindParam(":email", $email);
                $stmt->bindParam(":subject", $subject);
                $stmt->bindParam(":message", $message);
                $stmt->bindParam(":contact_method", $contact_method);

                // Execute query
                if ($stmt->execute()) {
                    // Success - set session message and redirect
                    $_SESSION['success_message'] = "Thank you for your message! We'll get back to you soon.";
                    header("Location: ../status_pages/success/contact-success.php");
                    exit();
                } else {
                    $errors[] = "Sorry, there was an error saving your message. Please try again.";
                }
            } else {
                $errors[] = "Database connection failed. Please try again later.";
            }
        } catch (PDOException $exception) {
            $errors[] = "Database error: " . $exception->getMessage();
        }
    }

    // If there are errors, store them in session and redirect back
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        $_SESSION['form_data'] = $_POST; // Save form data to repopulate
        header("Location: ../contact.php");
        exit();
    }
} else {
    // If not POST request, redirect to contact page
    header("Location: ../contact.php");
    exit();
}
