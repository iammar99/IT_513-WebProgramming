<?php
// This function displays error pages dynamically
function showErrorPage($errorCode, $errorTitle, $errorMessage, $suggestions = [])
{
    // Set the page title
    $pageTitle = $errorTitle;

    // Include header
    require_once 'includes/header.php';
?>

    <section class="content-section section-red">
        <h2 class="section-heading heading-red"><?php echo $errorCode; ?> - <?php echo $errorTitle; ?></h2>

        <article class="content-article article-red">
            <h3 class="article-heading">
                <span class="article-icon-red">▸</span> <?php echo $errorMessage; ?>
            </h3>

            <?php if (!empty($suggestions)): ?>
                <div class="content-article article-red mb-6">
                    <h4 class="article-heading">
                        <span class="article-icon-red">▸</span> What you can do:
                    </h4>
                    <ul class="bullet-list">
                        <?php foreach ($suggestions as $suggestion): ?>
                            <li><?php echo $suggestion; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <p class="text-body mb-2"><strong>Technical details:</strong> Error <?php echo $errorCode; ?> - <?php echo $errorTitle; ?></p>
            <div class="mt-6">
                <a href="index.php" class="btn-primary">
                    Return to Homepage
                </a>
            </div>
        </article>
    </section>

<?php
    // Include footer
    require_once 'includes/footer.php';
    exit(); // Stop further execution
}
?>